<?php
class G2tech_Owlslider_Block_Adminhtml_Owlslider_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{
		public function __construct()
		{
				parent::__construct();
				$this->setId("owlslider_tabs");
				$this->setDestElementId("edit_form");
				$this->setTitle(Mage::helper("owlslider")->__("Slider Information"));
		}
		protected function _beforeToHtml()
		{
				$this->addTab("form_section", array(
				"label" => Mage::helper("owlslider")->__("Slider Information"),
				"title" => Mage::helper("owlslider")->__("Slider Information"),
				"content" => $this->getLayout()->createBlock("owlslider/adminhtml_owlslider_edit_tab_form")->toHtml(),
				));
				$this->addTab("form_setting", array(
				"label" => Mage::helper("owlslider")->__("Slider Setting"),
				"title" => Mage::helper("owlslider")->__("Slider Setting"),
				"content" => $this->getLayout()->createBlock("owlslider/adminhtml_owlslider_edit_tab_setting")->toHtml(),
				));
				$this->addTab("form_slideimages", array(
				"label" => Mage::helper("owlslider")->__("Slider Images"),
				"title" => Mage::helper("owlslider")->__("Slider Images"),
				"content" => $this->getLayout()->createBlock("owlslider/adminhtml_owlslider_edit_tab_slideimages")->toHtml(),
				));
				return parent::_beforeToHtml();
		}

}
