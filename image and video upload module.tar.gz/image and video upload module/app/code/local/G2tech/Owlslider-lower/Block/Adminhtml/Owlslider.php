<?php


class G2tech_Owlslider_Block_Adminhtml_Owlslider extends Mage_Adminhtml_Block_Widget_Grid_Container{

	public function __construct()
	{

	$this->_controller = "adminhtml_owlslider";
	$this->_blockGroup = "owlslider";
	$this->_headerText = Mage::helper("core")->__("Owlslider Manager");
	$this->_addButtonLabel = Mage::helper("core")->__("Add New Item");
	parent::__construct();
	
	}

}
