<?php   
class G2tech_Owlslider_Block_Index extends Mage_Core_Block_Template{   
	public $slider_id;
	public function getSlider(){

	$slider_data=Mage::getModel("owlslider/owlslider")
			   ->getCollection()
			   ->addFieldToFilter('id',$this->slider_id);
	return $slider_data;
	}

	public function getSliderImages(){
	 $slider_images=Mage::getModel("owlslider/owlsliderimage")->getCollection()
				 ->addFieldToFilter('slider_id',$this->slider_id)
				 ->setOrder('slider_image_sortorder','ASC');
	}
}