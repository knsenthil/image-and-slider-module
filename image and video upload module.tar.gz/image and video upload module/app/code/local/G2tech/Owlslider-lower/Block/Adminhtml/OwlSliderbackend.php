<?php  

class G2tech_Owlslider_Block_Adminhtml_OwlSliderbackend extends Mage_Adminhtml_Block_Template {

}