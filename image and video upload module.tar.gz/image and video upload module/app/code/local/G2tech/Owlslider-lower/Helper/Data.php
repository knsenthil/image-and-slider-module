<?php
class G2tech_Owlslider_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 
