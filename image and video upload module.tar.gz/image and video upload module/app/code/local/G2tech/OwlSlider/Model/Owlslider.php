<?php

class G2tech_OwlSlider_Model_Owlslider extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("owlslider/owlslider");

    }

}
	 