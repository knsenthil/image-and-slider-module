<?php   
class G2tech_OwlSlider_Block_Owlslider extends Mage_Core_Block_Template{ 
  
	public $slider_id;
	
	public function getSlider(){

	$slider_data=Mage::getModel("owlslider/owlslider")
			   ->getCollection()
			   ->addFieldToFilter('id',$this->getSliderId());
	return $slider_data;
	}

	public function getSliderImages(){
	 $slider_images=Mage::getModel("owlslider/owlsliderimage")->getCollection()
				 ->addFieldToFilter('slider_id',$this->getSliderId())
				 ->setOrder('slider_image_sortorder','ASC');
		return $slider_images;
	}

}