<?php

class G2tech_OwlSlider_Block_Adminhtml_Owlslider_Edit_Tab_Setting extends Mage_Adminhtml_Block_Widget_Form {

    protected function _prepareForm() {

        $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset("owlslider_form2", array("legend" => Mage::helper("owlslider")->__("Slider Setting")));
        $fieldset->addField("slide_speed", "text", array(
            "label" => Mage::helper("owlslider")->__("Slide Speed"),
            "name" => "slide_speed",
            "value" => "200"
        ));
        $fieldset->addField("no_items", "text", array(
            "label" => Mage::helper("owlslider")->__("No of Item display"),
            "name" => "no_items",
            "value" => '4'
        ));
        $fieldset->addField("pagination_speed", "text", array(
            "label" => Mage::helper("owlslider")->__("Pagination Speed"),
            "name" => "pagination_speed",
            "value" => "800"
        ));
        $fieldset->addField('auto_play', 'radios', array(
            'label' => Mage::helper('owlslider')->__('Auto Play'),
            'name' => 'auto_play',
            'onclick' => "",
            'onchange' => "",
            'value' => '1',
            'values' => array(
                array('value' => '1', 'label' => 'True'),
                array('value' => '0', 'label' => 'False')
            ),
            'disabled' => false,
            'readonly' => false,
            'tabindex' => 1
        ));
        $fieldset->addField('navigation', 'radios', array(
            'label' => Mage::helper('owlslider')->__('Navigation'),
            'name' => 'navigation',
            'onclick' => "",
            'onchange' => "",
            'value' => '2',
            'values' => array(
                array('value' => '1', 'label' => 'True'),
                array('value' => '0', 'label' => 'False', 'checked' => true)
            ),
            'disabled' => false,
            'readonly' => false,
            'after_element_html' => '<small>(Display "next" and "prev" buttons.)</small>',
            'tabindex' => 1
        ));
        $fieldset->addField('pagination', 'radios', array(
            'label' => Mage::helper('owlslider')->__('Pagination'),
            'name' => 'pagination',
            'onclick' => "",
            'onchange' => "",
            'value' => '2',
            'values' => array(
                array('value' => '1', 'label' => 'True'),
                array('value' => '0', 'label' => 'False')
            ),
            'disabled' => false,
            'readonly' => false,
            'tabindex' => 1
        ));
        $fieldset->addField('responsive', 'radios', array(
            'label' => Mage::helper('owlslider')->__('Responsive'),
            'name' => 'responsive',
            'onclick' => "",
            'onchange' => "",
            'value' => '2',
            'values' => array(
                array('value' => '1', 'label' => 'True'),
                array('value' => '0', 'label' => 'False')
            ),
            'disabled' => false,
            'readonly' => false,
            'after_element_html' => '<small>(You can use Owl  on desktop-only websites too! Just change that to "false" to disable resposive capabilities.)</small>',
            'tabindex' => 1
        ));
        $fieldset->addField('auto_height', 'radios', array(
            'label' => Mage::helper('owlslider')->__('Auto Height'),
            'name' => 'auto_height',
            'onclick' => "",
            'onchange' => "",
            'value' => '2',
            'values' => array(
                array('value' => '1', 'label' => 'True'),
                array('value' => '0', 'label' => 'False')
            ),
            'disabled' => false,
            'readonly' => false,
            'tabindex' => 1
        ));



        if (Mage::getSingleton("adminhtml/session")->getOwlsliderData()) {
            $form->setValues(Mage::getSingleton("adminhtml/session")->getOwlsliderData());
            Mage::getSingleton("adminhtml/session")->setOwlsliderData(null);
        } elseif (Mage::registry("owlslider_data")) {
            $data = Mage::registry("owlslider_data")->getData();
            if (!empty($data)) {
                $form->setValues(Mage::registry("owlslider_data")->getData());
            }
        }
        return parent::_prepareForm();
    }

}
