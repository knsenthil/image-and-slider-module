<?php  

class G2tech_OwlSlider_Block_Adminhtml_OwlSliderbackend extends Mage_Adminhtml_Block_Template {

}