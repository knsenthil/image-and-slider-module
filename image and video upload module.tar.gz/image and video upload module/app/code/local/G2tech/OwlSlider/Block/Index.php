<?php   
class G2tech_OwlSlider_Block_Index extends Mage_Core_Block_Template{   
	public $slider_id;
	
	public function getSlider($category_id) {
	$slider_data=Mage::getModel("owlslider/owlslider")->getCollection();
	$slider_data->getSelect()->join('owlslider_image','main_table.id = owlslider_image.slider_id and main_table.slider_page_id ='.$category_id.' and main_table.slider_status = 1');
	$slider_data->getSelect()->order('owlslider_image.slider_image_sortorder ASC');
	//echo $slider_data->getSelect()->__toString(); exit;
	return $slider_data;
	}

	public function getSliderImages(){
	 $slider_images=Mage::getModel("owlslider/owlsliderimage")->getCollection()
				 ->addFieldToFilter('slider_id',$this->slider_id)
				 ->setOrder('slider_image_sortorder','ASC');
	}
	
	
}
