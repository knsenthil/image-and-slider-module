<?php

class G2tech_OwlSlider_Block_Adminhtml_Owlslider_Edit extends Mage_Adminhtml_Block_Widget_Form_Container {

    public function __construct() {

        parent::__construct();
        $this->_objectId = "id";
        $this->_blockGroup = "owlslider";
        $this->_controller = "adminhtml_owlslider";
        $this->_updateButton("save", "label", Mage::helper("owlslider")->__("Save Item"));
        $this->_updateButton("delete", "label", Mage::helper("owlslider")->__("Delete Item"));

        $this->_addButton("saveandcontinue", array(
            "label" => Mage::helper("owlslider")->__("Save And Continue Edit"),
            "onclick" => "saveAndContinueEdit()",
            "class" => "save",
                ), -100);



        $this->_formScripts[] = "

							function saveAndContinueEdit(){
								editForm.submit($('edit_form').action+'back/edit/');
							}
						";
    }

    public function getHeaderText() {
        if (Mage::registry("owlslider_data") && Mage::registry("owlslider_data")->getId()) {

            return Mage::helper("owlslider")->__("Edit Item '%s'", $this->htmlEscape(Mage::registry("owlslider_data")->getId()));
        } else {

            return Mage::helper("owlslider")->__("Add Item");
        }
    }

}
