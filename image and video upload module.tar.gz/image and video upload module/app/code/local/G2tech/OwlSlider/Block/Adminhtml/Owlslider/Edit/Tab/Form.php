<?php

class G2tech_OwlSlider_Block_Adminhtml_Owlslider_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form {

    protected function _prepareForm() {
		
        $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset("owlslider_form", array("legend" => Mage::helper("owlslider")->__("Slider information")));


        $fieldset->addField("slider_name", "text", array(
            "label" => Mage::helper("owlslider")->__("Slider Name"),
            "name" => "slider_name",
            'class' => 'required-entry',
            'required' => true
        ));
        if($this->getRequest()->getParam('id')) {
			$fieldset->addField("slider_page_id", "select", array(
            "label" => Mage::helper("owlslider")->__("Slider Visible Page"),
            "name" => "slider_page_id",
            'class' => 'required-entry',
             'disabled' => true,
				'readonly' => true,
            'values' => $this->_getAllSliderPages()
               ));
		} else {
			$fieldset->addField("slider_page_id", "select", array(
            "label" => Mage::helper("owlslider")->__("Slider Visible Page"),
            "name" => "slider_page_id",
            'class' => 'required-entry',
            'required' => true,
            'values' => $this->_getSliderPages(),
        ));
		}
        
        
          $fieldset->addField("slider_status", "select", array(
            "label" => Mage::helper("owlslider")->__("Status"),
            "name" => "slider_status",
            'values' => array(0=>'Inactive',1=>'Active'),
        ));
        $fieldset->addField('store_id', 'hidden', array(
                'name' => 'stores[]',
                'value' => Mage::app()->getStore(true)->getId()
            ));
        /*if (!Mage::app()->isSingleStoreMode()) {
            $fieldset->addField('store_id', 'multiselect', array(
                'name' => 'stores[]',
                'label' => Mage::helper('owlslider')->__('Store View'),
                'title' => Mage::helper('owlslider')->__('Store View'),
                'required' => true,
                'values' => Mage::getSingleton('adminhtml/system_store')
                        ->getStoreValuesForForm(false, true),
            ));
        } else {
            $fieldset->addField('store_id', 'hidden', array(
                'name' => 'stores[]',
                'value' => Mage::app()->getStore(true)->getId()
            ));
        } */



        if (Mage::getSingleton("adminhtml/session")->getOwlsliderData()) {
            $form->setValues(Mage::getSingleton("adminhtml/session")->getOwlsliderData());
            Mage::getSingleton("adminhtml/session")->setOwlsliderData(null);
        } elseif (Mage::registry("owlslider_data")) {
            $data = Mage::registry("owlslider_data")->getData();
            if (!empty($data)) {
                $form->setValues(Mage::registry("owlslider_data")->getData());
            }
        }
        return parent::_prepareForm();
    }

    protected function _filterStoreCondition($collection, $column) {
        if (!$value = $column->getFilter()->getValue()) {
            return;
        }
        $this->getCollection()->addStoreFilter($value);
    }

    protected function _getSliderPages() {
		$existing_page_sliders = Mage::getModel('owlslider/owlslider')->getCollection()->addFieldToSelect('slider_page_id');
		foreach($existing_page_sliders as $_data) {
			$id[] = $_data->getSliderPageId();
			}
        $collection =  Mage::getModel('owlslider/owlsliderpages')->getCollection()->addFieldToFilter('slider_unique_id',array('nin'=>$id));
        $pages[' '] ='Select Page';
        if(sizeof($collection)) {
			foreach($collection as $_collection) {
				$pages[$_collection->getSliderUniqueId()] = $_collection->getSliderPage();
			}
		}
		return $pages;
        
    }
    
    protected function _getAllSliderPages() {
		return Mage::getModel('owlslider/owlsliderpages')->getSliderVisiblePages();
	}

}
