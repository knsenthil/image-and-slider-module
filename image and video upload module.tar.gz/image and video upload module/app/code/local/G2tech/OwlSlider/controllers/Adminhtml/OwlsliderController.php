<?php

class G2tech_OwlSlider_Adminhtml_OwlsliderController extends Mage_Adminhtml_Controller_Action {

    protected function _initAction() {
        $this->loadLayout()->_setActiveMenu("owlslider/owlslider")->_addBreadcrumb(Mage::helper("adminhtml")->__("Owlslider  Manager"), Mage::helper("adminhtml")->__("Owlslider Manager"));
        return $this;
    }

    public function indexAction() {
        $this->_title($this->__("OwlSlider"));
        $this->_title($this->__("Manager Owlslider"));

        $this->_initAction();
        $this->renderLayout();
    }

    public function editAction() {
        $this->_title($this->__("OwlSlider"));
        $this->_title($this->__("Owlslider"));
        $this->_title($this->__("Edit Item"));

        $id = $this->getRequest()->getParam("id");
        $model = Mage::getModel("owlslider/owlslider")->load($id);
        if ($model->getId()) {
            Mage::register("owlslider_data", $model);
            $this->loadLayout();
            $this->_setActiveMenu("owlslider/owlslider");
            $this->_addBreadcrumb(Mage::helper("adminhtml")->__("Owlslider Manager"), Mage::helper("adminhtml")->__("Owlslider Manager"));
            $this->_addBreadcrumb(Mage::helper("adminhtml")->__("Owlslider Description"), Mage::helper("adminhtml")->__("Owlslider Description"));
            $this->getLayout()->getBlock("head")->setCanLoadExtJs(true);
            $this->_addContent($this->getLayout()->createBlock("owlslider/adminhtml_owlslider_edit"))->_addLeft($this->getLayout()->createBlock("owlslider/adminhtml_owlslider_edit_tabs"));
            $this->renderLayout();
        } else {
            Mage::getSingleton("adminhtml/session")->addError(Mage::helper("owlslider")->__("Item does not exist."));
            $this->_redirect("*/*/");
        }
    }

    public function newAction() {

        $this->_title($this->__("OwlSlider"));
        $this->_title($this->__("Owlslider"));
        $this->_title($this->__("New Item"));

        $id = $this->getRequest()->getParam("id");
        $model = Mage::getModel("owlslider/owlslider")->load($id);

        $data = Mage::getSingleton("adminhtml/session")->getFormData(true);
        if (!empty($data)) {
            $model->setData($data);
        }

        Mage::register("owlslider_data", $model);

        $this->loadLayout();
        $this->_setActiveMenu("owlslider/owlslider");

        $this->getLayout()->getBlock("head")->setCanLoadExtJs(true);

        $this->_addBreadcrumb(Mage::helper("adminhtml")->__("Owlslider Manager"), Mage::helper("adminhtml")->__("Owlslider Manager"));
        $this->_addBreadcrumb(Mage::helper("adminhtml")->__("Owlslider Description"), Mage::helper("adminhtml")->__("Owlslider Description"));


        $this->_addContent($this->getLayout()->createBlock("owlslider/adminhtml_owlslider_edit"))->_addLeft($this->getLayout()->createBlock("owlslider/adminhtml_owlslider_edit_tabs"));

        $this->renderLayout();
    }

    public function saveAction() {

        $post_data = $this->getRequest()->getPost();
       
       /* $no_items = 0;
        if (isset($post_data['simage'])) {
            $no_items = count($post_data['simage']); 
        } */
        $pages = array('20','24');
        if(in_array($post_data['slider_page_id'], $pages)) {
			 $post_data['store_id'] = 4;
		}
		else {
			 $post_data['store_id'] = 1;
		}
       
        if ($post_data) {
            try {

                /*if (isset($post_data['stores'])) {
                    if (in_array('0', $post_data['stores'])) {
                        $post_data['store_id'] = '0';
                    } else {
                        $post_data['store_id'] = implode(",", $post_data['stores']);
                    }
                    unset($post_data['stores']);
                } */
                // echo "<pre>"; print_r($post_data);exit;
                 /*$model = Mage::getModel("owlslider/owlslider")
                        ->addData($post_data);
                        echo "<pre>"; print_r($model->toArray());exit; */
                $model = Mage::getModel("owlslider/owlslider")
                        ->addData($post_data)
                        //->addData('store_id',$post_data['stores'])
                   //     ->setData('no_items', $post_data['no_items'])
                        ->setId($this->getRequest()->getParam("id"))
                        ->save();
                //echo count($post_data['simage']);
                //echo "<pre>";print_r($post_data['simage']); 
                if (isset($post_data['simage'])) {
                    $invalid_file_type = 0;
                    foreach ($post_data['simage'] as $_image) {
                        if(isset($_image['slider_image_path']) && $_image['slider_image_path'] !='') {
                            ++$invalid_file_type;
                        }
                    }
                    //echo $invalid_file_type; exit;
                    if(count($post_data['simage'])!=$invalid_file_type) {
                    //    echo 'inin'; exit;
                        Mage::getSingleton("adminhtml/session")->addError(Mage::helper("adminhtml")->__("Check the uploaded file type, there having some Disallowed file type. "));
                        $this->_redirect("*/*/edit", array("id" => $model->getId()));
                        return;
                    }
                    
                    $status = $this->saveImage($post_data['simage'], $model->getId());
                }
              
                
                Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Slider was successfully saved"));
                Mage::getSingleton("adminhtml/session")->setOwlsliderData(false);
                
                if ($this->getRequest()->getParam("back")) {
                    $this->_redirect("*/*/edit", array("id" => $model->getId()));
                    return;
                }
                $this->_redirect("*/*/");
                return;
            } catch (Exception $e) {
                Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
                Mage::getSingleton("adminhtml/session")->setOwlsliderData($this->getRequest()->getPost());
                $this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
                return;
            }
        }
        $this->_redirect("*/*/");
    }

    /* Save Add Image To Slider Imaage Table */

    public function saveImage($image_datas, $slider_id) {
        //echo "<pre>"; print_r($image_datas); exit;
        
        $dir = Mage::getBaseDir('base') . DS . "media/owlslider";
        if (is_dir($dir) === false) {
            mkdir($dir);
        }
        foreach ($image_datas as $key => $val) {
            $model = Mage::getModel("owlslider/owlsliderimage");
             /*if(!isset($val['slider_image_path']) && $val['slider_image_path']=='') {
                $dis_allowed_file_type = 1;
            }
           else {
                $dis_allowed_file_type = 1;
            } */
            
            $file = Mage::getBaseDir('base') . DS . $val['slider_image_path'];
            $val['slider_image_path'] = str_replace("tmp/", "", $val['slider_image_path']);
            $val['slider_id'] = $slider_id;
            /* Check the Remove action */
            if (!isset($val['remove'])) {
                //echo 'inin'; exit;
                $newfile = Mage::getBaseDir('base') . DS . $val['slider_image_path'];
                /* Save the new image and update exist */
                if ($val['id'] != '') {
                    $model->addData($val)
                            ->setData('slider_link', $val['slider_link'])
                            ->setId($val['id'])
                            ->save();
                } else {
                   
                    //if($file === Mage::getBaseDir('base').'/') {
                   //      $this->_redirect("*/*/edit", array("id" => $slider_id));
                      //   return;
                    //} 
                   /* $check = (isset($dis_allowed_file_type))?$dis_allowed_file_type:0;
                    if(!$check) {
                        
                    } */
                    copy($file, $newfile);
                        unset($val['id']);
                        $model->addData($val)
                                ->setData('slider_link', $val['slider_link'])
                                ->save();
                    
                }
            } else {
                /* Delete the image */
                if ($val['id'] != '') {
                    
                    $model->setId($val['id'])->delete();
                    unlink($file);
                }
            }
        }
        //get the slider count
        $image_model = Mage::getModel("owlslider/owlsliderimage")->getCollection()->addFieldToFilter('slider_id',$slider_id);
        $slider_model = Mage::getModel("owlslider/owlslider")->load($slider_id);
        $slider_model->setNoItems(count($image_model))->save();
        return (isset($dis_allowed_file_type))?$dis_allowed_file_type:0;
        //return $dis_allowed_file_type;
        //echo count($image_datas); exit;
    }

    public function deleteAction() {
        if ($this->getRequest()->getParam("id") > 0) {
            try {
                $model = Mage::getModel("owlslider/owlslider");
                $model->setId($this->getRequest()->getParam("id"))->delete();
                $slideimage_model = Mage::getModel("owlslider/owlsliderimage");
                $slideimage_model->setData("slider_link", $this->getRequest()->getParam("id"))->delete();
                Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item was successfully deleted"));
                $this->_redirect("*/*/");
            } catch (Exception $e) {
                Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
                $this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
            }
        }
        $this->_redirect("*/*/");
    }

    public function massRemoveAction() {
        try {
            $ids = $this->getRequest()->getPost('ids', array());
            foreach ($ids as $id) {
                $model = Mage::getModel("owlslider/owlslider");
                $model->setId($id)->delete();
                $slideimage_model = Mage::getModel("owlslider/owlsliderimage");
                $slideimage_model->setData("slider_link", $id)->delete();
            }
            Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item(s) was successfully removed"));
        } catch (Exception $e) {
            Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
        }
        $this->_redirect('*/*/');
    }

    /**
     * Export order grid to CSV format
     */
    public function exportCsvAction() {
        $fileName = 'owlslider.csv';
        $grid = $this->getLayout()->createBlock('owlslider/adminhtml_owlslider_grid');
        $this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
    }

    /**
     *  Export order grid to Excel XML format
     */
    public function exportExcelAction() {
        $fileName = 'owlslider.xml';
        $grid = $this->getLayout()->createBlock('owlslider/adminhtml_owlslider_grid');
        $this->_prepareDownloadResponse($fileName, $grid->getExcelFile($fileName));
    }

    public function uploadAction() {
        if (!empty($_FILES)) {
            $result = array();
            try {
                $uploader = new Varien_File_Uploader("Filedata");
                $uploader->setAllowRenameFiles(true);

                $uploader->setFilesDispersion(false);
                $uploader->setAllowCreateFolders(true);

                $path = Mage::getBaseDir('base') . DS . "media/tmp/owlslider"; //ex. Mage::getBaseDir('base') . DS ."my_uploads" . DS

                $uploader->setAllowedExtensions(array('jpg','jpeg','gif','png','mp4','mov','m4v','mv4','3gp','flv','avi','wmv')); //server-side validation of extension
              
                $uploadSaveResult = $uploader->save($path, $_FILES['Filedata']['name']);

                $result = array('file' => $uploadSaveResult['file'], 'slider_image_path' => "media/tmp/owlslider/" . $uploadSaveResult['file'], 'image_url' => Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA) . "tmp/owlslider/" . $uploadSaveResult['file']);
            } catch (Exception $e) {
                $result = array(
                    "error" => $e->getMessage(),
                    "errorCode" => $e->getCode(),
                    "status" => "error"
                );
            }
            //echo "<pre>"; print_r($result); exit;
            
            $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($result));
        }
    }

}
