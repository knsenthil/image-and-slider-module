-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 31, 2016 at 04:05 PM
-- Server version: 5.5.50-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `emmacosm_emmavert`
--

-- --------------------------------------------------------

--
-- Table structure for table `owlslider_image`
--

CREATE TABLE IF NOT EXISTS `owlslider_image` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Slider Images ID',
  `slider_image_title` text NOT NULL COMMENT 'Slider Image Title',
  `slider_link` text NOT NULL COMMENT 'Slider Image URL',
  `slider_image_sortorder` int(11) NOT NULL COMMENT 'Slider Image Sort Order',
  `slider_image_path` text NOT NULL COMMENT 'Slider Image Path',
  `slider_id` int(10) unsigned NOT NULL COMMENT 'ID From Owlslider foreign key',
  PRIMARY KEY (`id`),
  KEY `FK_OWLSLIDER_ID_OWLSLIDER_ID` (`slider_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='owlslider_image' AUTO_INCREMENT=58 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `owlslider_image`
--
ALTER TABLE `owlslider_image`
  ADD CONSTRAINT `FK_OWLSLIDER_ID_OWLSLIDER_ID` FOREIGN KEY (`slider_id`) REFERENCES `owlslider` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
