<?php
class G2tech_OwlSlider_Model_Mysql4_OwlsliderImage_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{

	public function _construct(){
		$this->_init("owlslider/OwlsliderImage");
	}

}
 
