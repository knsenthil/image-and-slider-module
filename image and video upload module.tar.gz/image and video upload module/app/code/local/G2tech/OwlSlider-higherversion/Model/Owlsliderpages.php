<?php

class G2tech_OwlSlider_Model_Owlsliderpages extends Mage_Core_Model_Abstract {

    protected function _construct() {

        $this->_init("owlslider/owlsliderpages");
    }
    
    public function getSliderVisiblePages() {
        $pagecollection = Mage::getModel('owlslider/owlsliderpages')->getCollection()->addFieldToFilter('slider_page_status', 1);
        $visible_page = array();

        $visible_page[] = 'Select Page';
        foreach ($pagecollection as $_page) {
            $visible_page[$_page->getId()] = $_page->getSliderPage();
        }
        return $visible_page;
    }

}
