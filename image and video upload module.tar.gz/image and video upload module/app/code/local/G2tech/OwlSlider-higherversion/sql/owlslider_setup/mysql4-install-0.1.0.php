<?php
$installer = $this;
$installer->startSetup();
$tableName = $installer->getTable('owlslider');
if ($installer->getConnection()->isTableExists($tableName) != true) {
$table = $installer->getConnection() 
         ->newTable($installer->getTable('owlslider'))
		 ->addColumn('id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
        'identity'  => true,
		'auto_increment' => true,
        'unsigned'  => true,
        'nullable'  => false,
        'primary'   => true,
        ), 'Slider ID')
		->addColumn('slider_name', Varien_Db_Ddl_Table::TYPE_TEXT, 300, array(
		'nullable'  => false
		),'Slider Name')
		->addColumn('store_id', Varien_Db_Ddl_Table::TYPE_TEXT, 300, array(
		'nullable'  => false
		),'Store Id')	
		->addColumn('no_items', Varien_Db_Ddl_Table::TYPE_INTEGER, null,array(
		'nullable'=>false
		),'No of Item display')
		->addColumn('slide_speed', Varien_Db_Ddl_Table::TYPE_INTEGER, null,array(
		'nullable'=>false
		),'Slide Speed')
		->addColumn('pagination_speed', Varien_Db_Ddl_Table::TYPE_INTEGER, null,array(
		'nullable'=>false
		),'Pagination Speed')
		->addColumn('auto_play', Varien_Db_Ddl_Table::TYPE_INTEGER, null,array(
		'nullable'=>false
		),'Auto Play')
		->addColumn('navigation', Varien_Db_Ddl_Table::TYPE_INTEGER, null,array(
		'nullable'=>false
		),'Navigation')
		->addColumn('pagination', Varien_Db_Ddl_Table::TYPE_INTEGER, null,array(
		'nullable'=>false
		),'Pagination')
		->addColumn('responsive', Varien_Db_Ddl_Table::TYPE_INTEGER, null,array(
		'nullable'=>false
		),'Responsive')
		->addColumn('auto_height', Varien_Db_Ddl_Table::TYPE_INTEGER, null,array(
		'nullable'=>false
		),'Auto Height');
		
		$installer->getConnection()->createTable($table);
	}	
$tableName = $installer->getTable('owlslider_image');
if ($installer->getConnection()->isTableExists($tableName) != true) {	
$table = $installer->getConnection() 
         ->newTable($installer->getTable('owlslider_image'))
		 ->addColumn('id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
        'identity'  => true,
		'auto_increment' => true,
        'unsigned'  => true,
        'nullable'  => false,
        'primary'   => true,
        ), 'Slider Images ID')
		->addColumn('slider_image_title', Varien_Db_Ddl_Table::TYPE_TEXT, 300, array(
		'nullable'  => false
		),'Slider Image Title')
		->addColumn('slider_link', Varien_Db_Ddl_Table::TYPE_TEXT, 300, array(
		'nullable'  => false
		),'Slider Image URL')
		->addColumn('slider_image_sortorder', Varien_Db_Ddl_Table::TYPE_INTEGER, null,array(
		'nullable'=>false
		),'Slider Image Sort Order')
		->addColumn('slider_image_path',Varien_Db_Ddl_Table::TYPE_TEXT,300,array(
		'nullable'=>false
		),'Slider Image Path')
		->addColumn('slider_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null,array(
		'nullable'=>false
		),'ID From Owlslider foreign key')
		->addForeignKey(
         $installer->getFkName('owlslider/owlslider', 'id', 'owlslider/owlslider','id'),
         'slider_id',
        $installer->getTable('owlslider/owlslider'), 
       'id',
         Varien_Db_Ddl_Table::ACTION_CASCADE, 
        Varien_Db_Ddl_Table::ACTION_CASCADE
);
$installer->getConnection()->createTable($table);
}
//demo 
//Mage::getModel('core/url_rewrite')->setId(null);
//demo 
$installer->endSetup();
	 