<?php


class G2tech_OwlSlider_Block_Adminhtml_Owlslider extends Mage_Adminhtml_Block_Widget_Grid_Container{

	public function __construct()
	{

	$this->_controller = "adminhtml_owlslider";
	$this->_blockGroup = "owlslider";
	$this->_headerText = Mage::helper("owlslider")->__("Slider Manager");
	$this->_addButtonLabel = Mage::helper("owlslider")->__("Add New Item");
	parent::__construct();
	
	}

}