<?php
class G2tech_OwlSlider_Block_Adminhtml_Owlslider_Edit_Tab_Image extends Mage_Adminhtml_Block_Widget{
       /**
     * Class constructor
     */
    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('owlslider/edit/tab/sliderimages.phtml');
	 }
	   public function getConfigJson($field)
    {
        $this->getConfig()->setParams(
            array(
                'form_key' => $this->getFormKey(),
                "field" => $field
            )
        );
        $this->getConfig()->setFileField('Filedata');
        $this->getConfig()->setUrl(Mage::getModel('adminhtml/url')->addSessionParam()->getUrl("*/*/upload", array("param1" => "value1")));
        $this->getConfig()->setFilters(array(
            'image documents' => array(
                'label' => Mage::helper('adminhtml')->__('Portable Document Format (.jpg,.jpeg,.gif,.png)'),
                'files' => array('*.jpg','*.jpeg','*.gif','*.png')
            )
        ));
        return Mage::helper('core')->jsonEncode($this->getConfig()->getData());
    }     

    public function getConfig()
    {
        if(is_null($this->_config)) {
            $this->_config = new Varien_Object();
        }

        return $this->_config;
    }
	public function getSliderImage(){
	      $data=Mage::registry("owlslider_data")->getData();
		   $slider_id=(!empty($data))?$data['id']:0;
	       $slider_image_colloection=Mage::getModel("owlslider/owlsliderimage")->getCollection()
		                             ->addFieldToFilter('slider_id',$slider_id);
		   return $slider_image_colloection;						 
	}

}
