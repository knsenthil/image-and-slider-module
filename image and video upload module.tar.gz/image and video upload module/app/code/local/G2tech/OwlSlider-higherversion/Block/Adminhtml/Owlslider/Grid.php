<?php

class G2tech_OwlSlider_Block_Adminhtml_Owlslider_Grid extends Mage_Adminhtml_Block_Widget_Grid {

    public function __construct() {
        parent::__construct();
        $this->setId("owlsliderGrid");
        $this->setDefaultSort("id");
        $this->setDefaultDir("DESC");
        $this->setSaveParametersInSession(true);
    }

    protected function _prepareCollection() {
        $collection = Mage::getModel("owlslider/owlslider")->getCollection();
        $collection->getSelect()->joinLeft('owlslider_pages','main_table.slider_page_id = owlslider_pages.id',array('slider_page'));
        foreach ($collection as $link) {
            if ($link->getStoreId() && $link->getStoreId() != 0) {
                $link->setStoreId(explode(',', $link->getStoreId()));
            } else {
                $link->setStoreId(array('0'));
            }
        }
        //echo $collection->getSelect()->__toString(); exit;
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns() {
        $this->addColumn("id", array(
            "header" => Mage::helper("owlslider")->__("ID"),
            "align" => "right",
            "width" => "50px",
            "type" => "number",
            "index" => "id",
        ));

        $this->addColumn("slider_name", array(
            "header" => Mage::helper("owlslider")->__("Slider Name"),
            "index" => "slider_name",
        ));
        $this->addColumn("slider_page_id", array(
            "header" => Mage::helper("owlslider")->__("Slider Visible Page"),
            "index" => "slider_page_id",
            "type"      => "options",
            "options"   => $this->_getSliderPages(),
        ));
        if (!Mage::app()->isSingleStoreMode()) {
            $this->addColumn('store_id', array(
                'header' => Mage::helper('owlslider')->__('Store View'),
                'index' => 'store_id',
                'type' => 'store',
                'store_all' => true,
                'store_view' => true,
                'sortable' => true,
                'filter_condition_callback' => array($this,
                    '_filterStoreCondition'),
            ));
        }
        /*$this->addExportType('//exportCsv', Mage::helper('sales')->__('CSV'));
        $this->addExportType('//exportExcel', Mage::helper('sales')->__('Excel')); */

        return parent::_prepareColumns();
    }

    public function getRowUrl($row) {
        return $this->getUrl("*/*/edit", array("id" => $row->getId()));
    }

    protected function _filterStoreCondition($collection, $column) {
        if (!$value = $column->getFilter()->getValue()) {
            return;
        }
        $this->getCollection()->addStoreFilter($value);
    }

    protected function _prepareMassaction() {
        $this->setMassactionIdField('id');
        $this->getMassactionBlock()->setFormFieldName('ids');
        $this->getMassactionBlock()->setUseSelectAll(true);
        $this->getMassactionBlock()->addItem('remove_owlslider', array(
            'label' => Mage::helper('owlslider')->__('Remove Owlslider'),
            'url' => $this->getUrl('*/adminhtml_owlslider/massRemove'),
            'confirm' => Mage::helper('owlslider')->__('Are you sure?')
        ));
        return $this;
    }
    
     protected function _getSliderPages() {
        return Mage::getModel('owlslider/owlsliderpages')->getSliderVisiblePages();
    }
    
     /**
     * Function that handle filter on custom table
     *
     * @param $collection
     * @param $column
     */
   

}
