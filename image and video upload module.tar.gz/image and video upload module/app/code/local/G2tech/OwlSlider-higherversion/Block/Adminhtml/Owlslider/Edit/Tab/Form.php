<?php

class G2tech_OwlSlider_Block_Adminhtml_Owlslider_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form {

    protected function _prepareForm() {

        $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset("owlslider_form", array("legend" => Mage::helper("owlslider")->__("Item information")));


        $fieldset->addField("slider_name", "text", array(
            "label" => Mage::helper("owlslider")->__("Slider Name"),
            "name" => "slider_name",
            'class' => 'required-entry',
            'required' => true
        ));
        $fieldset->addField("slider_page_id", "select", array(
            "label" => Mage::helper("owlslider")->__("Slider Visible Page"),
            "name" => "slider_page_id",
            'class' => 'required-entry',
            'required' => true,
            'values' => $this->_getSliderPages(),
        ));
        if (!Mage::app()->isSingleStoreMode()) {
            $fieldset->addField('store_id', 'multiselect', array(
                'name' => 'stores[]',
                'label' => Mage::helper("owlslider")->__('Store View'),
                'title' => Mage::helper("owlslider")->__('Store View'),
                'required' => true,
                'values' => Mage::getSingleton('adminhtml/system_store')
                        ->getStoreValuesForForm(false, true),
            ));
        } else {
            $fieldset->addField('store_id', 'hidden', array(
                'name' => 'stores[]',
                'value' => Mage::app()->getStore(true)->getId()
            ));
        }



        if (Mage::getSingleton("adminhtml/session")->getOwlsliderData()) {
            $form->setValues(Mage::getSingleton("adminhtml/session")->getOwlsliderData());
            Mage::getSingleton("adminhtml/session")->setOwlsliderData(null);
        } elseif (Mage::registry("owlslider_data")) {
            $data = Mage::registry("owlslider_data")->getData();
            if (!empty($data)) {
                $form->setValues(Mage::registry("owlslider_data")->getData());
            }
        }
        return parent::_prepareForm();
    }

    protected function _filterStoreCondition($collection, $column) {
        if (!$value = $column->getFilter()->getValue()) {
            return;
        }
        $this->getCollection()->addStoreFilter($value);
    }

    protected function _getSliderPages() {
        return Mage::getModel('owlslider/owlsliderpages')->getSliderVisiblePages();
    }

}
